# Time-stamp: "Sat Jul 14 00:27:24 2001 by Automatic Bizooty (__blocks2pm.plx)"
$Text::Unidecode::Char[0x32] = [
qq{(g)}, qq{(n)}, qq{(d)}, qq{(r)}, qq{(m)}, qq{(b)}, qq{(s)}, qq{()}, qq{(j)}, qq{(c)}, qq{(k)}, qq{(t)}, qq{(p)}, qq{(h)}, qq{(ga)}, qq{(na)},
qq{(da)}, qq{(ra)}, qq{(ma)}, qq{(ba)}, qq{(sa)}, qq{(a)}, qq{(ja)}, qq{(ca)}, qq{(ka)}, qq{(ta)}, qq{(pa)}, qq{(ha)}, qq{(ju)}, '[?]', '[?]', '[?]',
qq{(1) }, qq{(2) }, qq{(3) }, qq{(4) }, qq{(5) }, qq{(6) }, qq{(7) }, qq{(8) }, qq{(9) }, qq{(10) }, qq{(Yue) }, qq{(Huo) }, qq{(Shui) }, qq{(Mu) }, qq{(Jin) }, qq{(Tu) },
qq{(Ri) }, qq{(Zhu) }, qq{(You) }, qq{(She) }, qq{(Ming) }, qq{(Te) }, qq{(Cai) }, qq{(Zhu) }, qq{(Lao) }, qq{(Dai) }, qq{(Hu) }, qq{(Xue) }, qq{(Jian) }, qq{(Qi) }, qq{(Zi) }, qq{(Xie) },
qq{(Ji) }, qq{(Xiu) }, qq{<<}, qq{>>}, '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]',
'[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]',
qq{(g)}, qq{(n)}, qq{(d)}, qq{(r)}, qq{(m)}, qq{(b)}, qq{(s)}, qq{()}, qq{(j)}, qq{(c)}, qq{(k)}, qq{(t)}, qq{(p)}, qq{(h)}, qq{(ga)}, qq{(na)},
qq{(da)}, qq{(ra)}, qq{(ma)}, qq{(ba)}, qq{(sa)}, qq{(a)}, qq{(ja)}, qq{(ca)}, qq{(ka)}, qq{(ta)}, qq{(pa)}, qq{(ha)}, '[?]', '[?]', '[?]', 'KIS ',
qq{(1) }, qq{(2) }, qq{(3) }, qq{(4) }, qq{(5) }, qq{(6) }, qq{(7) }, qq{(8) }, qq{(9) }, qq{(10) }, qq{(Yue) }, qq{(Huo) }, qq{(Shui) }, qq{(Mu) }, qq{(Jin) }, qq{(Tu) },
qq{(Ri) }, qq{(Zhu) }, qq{(You) }, qq{(She) }, qq{(Ming) }, qq{(Te) }, qq{(Cai) }, qq{(Zhu) }, qq{(Lao) }, qq{(Mi) }, qq{(Nan) }, qq{(Nu) }, qq{(Shi) }, qq{(You) }, qq{(Yin) }, qq{(Zhu) },
qq{(Xiang) }, qq{(Xiu) }, qq{(Xie) }, qq{(Zheng) }, qq{(Shang) }, qq{(Zhong) }, qq{(Xia) }, qq{(Zuo) }, qq{(You) }, qq{(Yi) }, qq{(Zong) }, qq{(Xue) }, qq{(Jian) }, qq{(Qi) }, qq{(Zi) }, qq{(Xie) },
qq{(Ye) }, '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]',
'1M', '2M', '3M', '4M', '5M', '6M', '7M', '8M', '9M', '10M', '11M', '12M', '[?]', '[?]', '[?]', '[?]',
'a', 'i', 'u', 'u', 'o', 'ka', 'ki', 'ku', 'ke', 'ko', 'sa', 'si', 'su', 'se', 'so', 'ta',
'ti', 'tu', 'te', 'to', 'na', 'ni', 'nu', 'ne', 'no', 'ha', 'hi', 'hu', 'he', 'ho', 'ma', 'mi',
'mu', 'me', 'mo', 'ya', 'yu', 'yo', 'ra', 'ri', 'ru', 're', 'ro', 'wa', 'wi', 'we', 'wo',
];
1;
